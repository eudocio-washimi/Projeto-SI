﻿Public Class frm_cadastro
    Private Sub img_foto_Click(sender As Object, e As EventArgs) Handles img_foto.Click
        Try
            With OpenFileDialog1
                .Title = "Selecione uma Foto"
                .InitialDirectory = Application.StartupPath & "\Fotos\"
                .ShowDialog()
                diretorio = .FileName
                diretorio = diretorio.Replace("\", "/")
                img_foto.Load(diretorio)
            End With
        Catch ex As Exception
            img_foto.Load(Application.StartupPath & "\Fotos\nova_foto.png")
            MsgBox("Erro ao selecionar foto: " & ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub frm_cadastro_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If db Is Nothing OrElse db.State <> ADODB.ObjectStateEnum.adStateOpen Then
            MsgBox("Erro: Conexão não disponível.", MsgBoxStyle.Critical) : Me.Close() : Exit Sub
        End If

        If tipoUsuarioAtual = "Administrador" Then
            dgv_dados.Visible = True
            ToolStrip1.Visible = True
            carregar_dados()
            carregar_tipo_dados()
        Else
            dgv_dados.Visible = False
            ToolStrip1.Visible = False
        End If
        txt_cpf_DoubleClick(Nothing, EventArgs.Empty)
    End Sub

    Private Sub btn_gravar_Click(sender As Object, e As EventArgs) Handles btn_gravar.Click
        Try
            ' Validações (Senha confere, CPF, Nome, Email obrigatórios, etc.)
            If txt_senha.Text <> txt_conf_senha.Text Then
                MsgBox("As senhas não conferem!", MsgBoxStyle.Exclamation) : txt_senha.Focus() : Exit Sub
            End If
            If String.IsNullOrWhiteSpace(txt_cpf.Text) OrElse txt_cpf.Text = "   .   .   -" Then
                MsgBox("CPF é obrigatório!", MsgBoxStyle.Exclamation) : txt_cpf.Focus() : Exit Sub
            End If
            If String.IsNullOrWhiteSpace(txt_nome.Text) Then
                MsgBox("Nome é obrigatório!", MsgBoxStyle.Exclamation) : txt_nome.Focus() : Exit Sub
            End If
            If String.IsNullOrWhiteSpace(txt_email.Text) Then
                MsgBox("E-mail é obrigatório!", MsgBoxStyle.Exclamation) : txt_email.Focus() : Exit Sub
            End If

            ' --- Verifica se CPF já existe em tb_clientes ---
            sql = $"SELECT * FROM tb_clientes WHERE cpf='{txt_cpf.Text}'"
            rs = New ADODB.Recordset
            rs.Open(sql, db)
            Dim clienteExiste As Boolean = Not rs.EOF
            If rs.State = ADODB.ObjectStateEnum.adStateOpen Then rs.Close()

            ' --- Verifica se E-MAIL já existe em tb_usuarios (evitar duplicados) ---
            Dim emailAtual As String = ""
            If clienteExiste Then ' Pega o email antigo se for update
                sql = $"SELECT email FROM tb_clientes WHERE cpf='{txt_cpf.Text}'"
                rs.Open(sql, db)
                If Not rs.EOF Then emailAtual = rs.Fields("email").Value.ToString()
                If rs.State = ADODB.ObjectStateEnum.adStateOpen Then rs.Close()
            End If

            If txt_email.Text <> emailAtual Then ' Só verifica email se ele mudou ou é novo
                sql = $"SELECT * FROM tb_usuarios WHERE nome_usuario='{txt_email.Text}'"
                rs.Open(sql, db)
                If Not rs.EOF Then
                    MsgBox("Este e-mail já está sendo usado como login por outro usuário!", MsgBoxStyle.Exclamation)
                    If rs.State = ADODB.ObjectStateEnum.adStateOpen Then rs.Close()
                    txt_email.Focus()
                    Exit Sub
                End If
                If rs.State = ADODB.ObjectStateEnum.adStateOpen Then rs.Close()
            End If
            ' --- Fim Verificações ---


            If clienteExiste Then ' UPDATE
                sql = $"UPDATE tb_clientes SET nome='{txt_nome.Text}',
                                        data_nasc='{cmb_data_nasc.Value.ToShortDateString}',
                                        fone='{txt_fone.Text}',
                                        email='{txt_email.Text}',
                                        foto='{diretorio}'
                   WHERE cpf='{txt_cpf.Text}'"
                db.Execute(UCase(sql))

                ' Atualiza tb_usuarios SE e-mail ou senha mudaram
                Dim sqlUsuario As String = ""
                If txt_email.Text <> emailAtual Then ' Se email mudou, atualiza nome_usuario
                    sqlUsuario = $"UPDATE tb_usuarios SET nome_usuario = '{txt_email.Text}'"
                End If
                If Not String.IsNullOrEmpty(txt_senha.Text) Then ' Se senha foi digitada, atualiza senha_usuario
                    If sqlUsuario <> "" Then sqlUsuario &= "," Else sqlUsuario = "UPDATE tb_usuarios SET" ' Junta os updates se necessário
                    sqlUsuario &= $" senha_usuario = '{txt_senha.Text}'"
                End If

                If sqlUsuario <> "" Then ' Se houve mudança no email ou senha
                    sqlUsuario &= $" WHERE nome_usuario = '{emailAtual}'" ' Busca pelo email ANTIGO para atualizar
                    db.Execute(UCase(sqlUsuario))
                End If

                MsgBox("Dados alterados com sucesso!", MsgBoxStyle.Information)

            Else ' INSERT
                ' Senha obrigatória para novo cadastro
                If String.IsNullOrEmpty(txt_senha.Text) Then
                    MsgBox("Senha é obrigatória para novo cadastro!", MsgBoxStyle.Exclamation) : txt_senha.Focus() : Exit Sub
                End If

                ' Insere na tb_clientes
                sql = $"INSERT INTO tb_clientes (cpf, nome, data_nasc, fone, email, foto) VALUES
                   ('{txt_cpf.Text}', '{txt_nome.Text}', '{cmb_data_nasc.Value.ToShortDateString}',
                    '{txt_fone.Text}','{txt_email.Text}','{diretorio}')"
                db.Execute(UCase(sql))

                ' Insere na tb_usuarios
                sql = $"INSERT INTO tb_usuarios (nome_usuario, senha_usuario, tipo_usuario) VALUES
                   ('{txt_email.Text}', '{txt_senha.Text}', 'Usuario')"
                db.Execute(UCase(sql))

                MsgBox("Cliente cadastrado com sucesso!", MsgBoxStyle.Information)
            End If

            ' Limpeza e Recarga (como antes)
            txt_cpf.Clear() : txt_nome.Clear() : cmb_data_nasc.Value = Now
            txt_fone.Clear() : txt_email.Clear() : txt_senha.Clear() : txt_conf_senha.Clear()
            img_foto.Load(Application.StartupPath & "\Fotos\nova_foto.png")
            txt_cpf.Focus()
            If tipoUsuarioAtual = "Administrador" Then carregar_dados()

        Catch ex As Exception
            MsgBox("Erro ao gravar: " & ex.Message, MsgBoxStyle.Critical)
        Finally
            If rs IsNot Nothing AndAlso rs.State = ADODB.ObjectStateEnum.adStateOpen Then rs.Close()
            rs = Nothing
        End Try
    End Sub

    Private Sub txt_cpf_LostFocus(sender As Object, e As EventArgs) Handles txt_cpf.LostFocus
        Try
            sql = $"select * from tb_clientes where cpf='{txt_cpf.Text}'"
            rs = New ADODB.Recordset
            rs.Open(sql, db)
            If Not rs.EOF Then
                txt_nome.Text = rs.Fields("nome").Value
                cmb_data_nasc.Value = rs.Fields("data_nasc").Value
                txt_fone.Text = rs.Fields("fone").Value
                txt_email.Text = rs.Fields("email").Value
                diretorio = rs.Fields("foto").Value.ToString()
                Try
                    img_foto.Load(diretorio)
                Catch exImg As Exception
                    img_foto.Load(Application.StartupPath & "\Fotos\nova_foto.png")
                End Try
            Else
                txt_nome.Clear()
                cmb_data_nasc.Value = Now
                txt_fone.Clear()
                txt_email.Clear()
                img_foto.Load(Application.StartupPath & "\Fotos\nova_foto.png")
                txt_nome.Focus()
            End If
        Catch ex As Exception
            MsgBox("Erro ao consultar CPF! Detalhes: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        Finally
            If rs IsNot Nothing AndAlso rs.State = ADODB.ObjectStateEnum.adStateOpen Then
                rs.Close()
            End If
            rs = Nothing
        End Try
    End Sub

    Private Sub txt_cpf_DoubleClick(sender As Object, e As EventArgs) Handles txt_cpf.DoubleClick
        txt_cpf.Clear()
        txt_nome.Clear()
        cmb_data_nasc.Value = Now
        txt_fone.Clear()
        txt_email.Clear()
        img_foto.Load(Application.StartupPath & "\Fotos\nova_foto.png")
        txt_cpf.Focus()
    End Sub

    Private Sub txt_buscar_TextChanged(sender As Object, e As EventArgs) Handles txt_buscar.TextChanged
        Try
            If db Is Nothing OrElse db.State <> ADODB.ObjectStateEnum.adStateOpen Then Exit Sub

            With dgv_dados
                Dim cmd As New ADODB.Command
                Dim paramBusca As ADODB.Parameter

                cmd.ActiveConnection = db
                cmd.CommandType = ADODB.CommandTypeEnum.adCmdText

                If cmb_campo.Text = "CPF" Then
                    cmd.CommandText = "SELECT * FROM tb_clientes WHERE cpf LIKE ?"
                Else
                    cmd.CommandText = "SELECT * FROM tb_clientes WHERE nome LIKE ?"
                End If

                paramBusca = cmd.CreateParameter("busca", ADODB.DataTypeEnum.adVarWChar, ADODB.ParameterDirectionEnum.adParamInput, 255, txt_buscar.Text & "%")
                cmd.Parameters.Append(paramBusca)

                rs = New ADODB.Recordset
                rs.Open(cmd, , ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly) ' Abre com o Command

                cont = 1
                .Rows.Clear()
                Do While Not rs.EOF
                    .Rows.Add(cont, rs.Fields("cpf").Value, rs.Fields("nome").Value, Nothing, Nothing) ' Usa nomes dos campos
                    rs.MoveNext()
                    cont = cont + 1
                Loop
            End With
        Catch ex As Exception
            MsgBox("Erro ao buscar dados: " & ex.Message, MsgBoxStyle.Critical)
        Finally
            If rs IsNot Nothing AndAlso rs.State = ADODB.ObjectStateEnum.adStateOpen Then
                rs.Close()
            End If
            rs = Nothing
        End Try
    End Sub

    Private Sub dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick
        Try
            If e.RowIndex >= 0 Then
                aux_cpf = dgv_dados.Rows(e.RowIndex).Cells(1).Value.ToString()

                If e.ColumnIndex = 3 Then
                    sql = $"SELECT * FROM tb_clientes WHERE cpf ='{aux_cpf}'"
                    rs = New ADODB.Recordset
                    rs.Open(sql, db)
                    If Not rs.EOF Then
                        diretorio = rs.Fields("foto").Value.ToString()
                        txt_cpf.Text = rs.Fields("cpf").Value
                        txt_nome.Text = rs.Fields("nome").Value
                        cmb_data_nasc.Value = rs.Fields("data_nasc").Value
                        txt_fone.Text = rs.Fields("fone").Value
                        txt_email.Text = rs.Fields("email").Value
                        Try
                            img_foto.Load(diretorio)
                        Catch exImg As Exception
                            img_foto.Load(Application.StartupPath & "\Fotos\nova_foto.png")
                        End Try
                    End If
                    If rs.State = ADODB.ObjectStateEnum.adStateOpen Then rs.Close()

                ElseIf e.ColumnIndex = 4 Then
                    resp = MsgBox("Deseja realmente Excluir o cliente com CPF: " & aux_cpf & "?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")
                    If resp = MsgBoxResult.Yes Then
                        sql = $"DELETE FROM tb_clientes WHERE cpf='{aux_cpf}'"
                        db.Execute(sql)
                        carregar_dados()
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox("Erro no Grid! Detalhes: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
            If rs IsNot Nothing AndAlso rs.State = ADODB.ObjectStateEnum.adStateOpen Then rs.Close()
        Finally
            rs = Nothing
        End Try
    End Sub

End Class